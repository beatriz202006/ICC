import pandas as pd
import matplotlib.pyplot as plt
import os

# ======== Função para gerar gráficos ========
def plot_metric(csv_path, title, ylabel, output_png):
    print(f"Gerando gráfico: {title}")

    df = pd.read_csv(csv_path)

    # Colunas corretas
    x = df["N"]
    v1 = df["V1"]
    v2 = df["V2"]

    plt.figure(figsize=(10,6))
    plt.plot(x, v1, marker="o", label="Versão V1")
    plt.plot(x, v2, marker="o", label="Versão V2")

    plt.xscale("log")
    plt.xlabel("Tamanho N (log)")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.legend()

    plt.tight_layout()
    plt.savefig(output_png)
    plt.close()


# ========= GERA GRÁFICOS DE OP1 =========
print("Gerando gráficos OP1...")

plot_metric(
    "TAB_OP1/TEMPO_op1.csv",
    "Tempo — OP1",
    "Tempo (ms)",
    "grafico_TEMPO_OP1.png",
)

plot_metric(
    "TAB_OP1/L1CACHE_op1.csv",
    "Cache miss L1/L2 — OP1",
    "Miss Ratio",
    "grafico_L1CACHE_OP1.png",
)

plot_metric(
    "TAB_OP1/L3_op1.csv",
    "Banda de Memória L3 — OP1",
    "Bandwidth (MB/s)",
    "grafico_L3_OP1.png",
)

plot_metric(
    "TAB_OP1/FLOPS_DP_op1.csv",
    "FLOPS DP — OP1",
    "MFLOP/s",
    "grafico_FLOPS_DP_OP1.png",
)


# ========= GERA GRÁFICOS DE OP2 =========
print("Gerando gráficos OP2...")

plot_metric(
    "TAB_OP2/TEMPO_op2.csv",
    "Tempo — OP2",
    "Tempo (ms)",
    "grafico_TEMPO_OP2.png",
)

plot_metric(
    "TAB_OP2/L1CACHE_op2.csv",
    "Cache miss L1/L2 — OP2",
    "Miss Ratio",
    "grafico_L1CACHE_OP2.png",
)

plot_metric(
    "TAB_OP2/L3_op2.csv",
    "Banda de Memória L3 — OP2",
    "Bandwidth (MB/s)",
    "grafico_L3_OP2.png",
)

plot_metric(
    "TAB_OP2/FLOPS_DP_op2.csv",
    "FLOPS DP — OP2",
    "MFLOP/s",
    "grafico_FLOPS_DP_OP2.png",
)

print("\nTodos os gráficos foram gerados!")
